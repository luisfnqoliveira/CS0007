
import java.io.*;
import java.util.Scanner;

public class Main {


    static ListOfFriends lof = new ListOfFriends(1);

    public static void storeFriends(String path) throws Exception {
        File f = new File(path);
        FileWriter fileWriter = new FileWriter(f);
        PrintWriter printWriter = new PrintWriter(fileWriter);
        printWriter.println(lof);
        printWriter.close();
    }

    /**
     *
     * @param path - where in my Hard Drive (HD) is the file I want to load
     * @throws Exception
     */
    public static void loadFriends(String path) throws Exception {

        File f = new File(path);
        Scanner fileScanner = new Scanner(f);

//        int lineNumber = 1;
        while ( fileScanner.hasNext() ) {
            String name = fileScanner.next();
            int age = fileScanner.nextInt();
            int height = fileScanner.nextInt();
//            System.out.println(lineNumber + ": " +
//                    name + " " +
//                    age + " " +
//                    height);
//
            Friend friend = new Friend(name, age, height);
            lof.addFriend(friend);

//            lineNumber++;
        }

        fileScanner.close();

    }


    public static void main(String[] args) throws Exception {

        String filePath = args[0];
        System.out.println("Using file:" + filePath);

        String input="";
        while( ! input.equals("e") ) {
            System.out.println("What do you want to do?");
            System.out.println("   (a) add a friend");
            System.out.println("   (r) remove a friend");
            System.out.println("   (u) update a friend");
            System.out.println("   (p) prints list of friends");
            System.out.println("   (l) load");
            System.out.println("   (s) save");
            System.out.println("   (e) exit");

            Scanner kbd = new Scanner(System.in);
            input = kbd.next();
            String name;
            switch (input) {
                case "a":
                    lof.addFriend(new Friend());
                    break;
                case "r":
                    System.out.println("What is the name of the friend you want to remove?");
                    name = kbd.next();
                    lof.removeFriend(name);
                    break;
                case "p":
                    System.out.println(lof);
                    break;
                case "u":
                    System.out.println("What is the name of the friend you want to update?");
                    name = kbd.next();
                    lof.updateFriend(name);
                    break;
                case "l":
                    loadFriends(filePath);
                    break;
                case "s":
                    storeFriends(filePath);
                    break;
                default:
                    break;
            }
        }


    }


}
