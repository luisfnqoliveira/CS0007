import java.util.Scanner;

public class Friend {

    private String name;
    private int age;
    private int height;

    public Friend() {
        //ask the user
        Scanner kbd = new Scanner(System.in);

        System.out.println("What is your friend's name?");
        String name = kbd.next();

        System.out.println("What is your friend's age?");
        int age = kbd.nextInt();

        System.out.println("What is your friend's height?");
        int height = kbd.nextInt();

        this.name = name;
        this.age = age;
        this.height = height;

    }

    public Friend( String name, int age, int height) {
        this.name = name;
        this.age = age;
        this.height = height;
    }


    public String getName() {
        return name;
    }

    public int getHeight() {
        return height;
    }

    public int getAge() {
        return age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return  name + " " +
                age + " " +
                height;
    }
}
