import java.util.Arrays;
import java.util.Scanner;

public class ListOfFriends {

    private Friend[] friends;
    private int filledFriends; // In the array friends, how many are valid entries


    public ListOfFriends() {
        friends = new Friend[2];
        filledFriends = 0;
    }

    public ListOfFriends(int predictedNumberOfFriends) {
        friends = new Friend[predictedNumberOfFriends];
        filledFriends = 0;
    }

    public void addFriend(Friend friend) {
        if( friends.length <= filledFriends ){
            tooManyFriends();
        }
        friends[filledFriends++] = friend;
    }

    private void tooManyFriends() {
        // Increase the size of the friends array
        Friend[] largerFriends = new Friend[friends.length*2];
        for (int i = 0; i<filledFriends; i++) {
            largerFriends[i] = friends[i];
        }
        friends = largerFriends;
    }

    private int findIndexOfFriend(String name) {

        for( int i = 0; i<filledFriends; i++) {
            // check if the friend has the right name
            if(friends[i].getName().equals(name)) {
                return i;
            }
        }
        return filledFriends;
    }

    public boolean hasFriend(String name) {
        return filledFriends != findIndexOfFriend(name);
    }

    public void removeFriend(String name) {

        // we need to find the index of the array where the name matches
        int indexOfFriend = findIndexOfFriend(name);
        // if the friend doesn't exist, I leave
        if( indexOfFriend == filledFriends ) {
            System.out.println("Friend was not found!");
            return;
        }

        friends[indexOfFriend] = friends[ filledFriends-1 ];
        filledFriends--;


    }

    public void updateFriend(String name) {

        // we need to find the index of the array where the name matches
        int indexOfFriend = findIndexOfFriend(name);
        // if the friend doesn't exist, I leave
        if( indexOfFriend == filledFriends ) {
            System.out.println("Friend was not found!");
            return;
        }

        System.out.println("What information do you want to update?");
        System.out.println("  (a) Age");
        System.out.println("  (h) Height");

        Scanner kbd = new Scanner(System.in);
        String input = kbd.next();

        switch (input) {
            case "a":
                System.out.println("What's the new age?");
                int age = kbd.nextInt();
                friends[indexOfFriend].setAge(age);
                break;
            case "h":
                System.out.println("What's the new height?");
                int height = kbd.nextInt();
                friends[indexOfFriend].setHeight(height);
                break;
            default:
                System.out.println("I don't know about that!");
                break;
        }

    }

    @Override
    public String toString() {
        String output = "";
        for (int i = 0; i < filledFriends; i++) {
            output += friends[i] + "\n";
        }
        return output;
    }
}
