/**
 * Pot of gold class - Simulates a mission to a pot of gold coins
 */
public class PotOfGoldCoins {

    /**
     * Number of days that takes to reach this pot
     */
    private int nDays = 0;

    /**
     * Number of gold coins remaining in the this pot
     */
    private int nCoins = 0;

    /**
     * Duration of the current trip to this pot
     */
    private int missionTime = 0;

    /**
     * Flag that signals if the trip to the pot has been completed
     */
    private boolean missionDone = false;

    /**
     * Dwarf assigned to this pot, if any
     */
    private Dwarf dwarf = null;

    /**
     * Initialize the pot of gold
     * @param coins Initial number of coins in the pot
     * @param days Number of days to retrieve coins from the pot
     */
    public PotOfGoldCoins(int coins, int days) {
        nCoins = coins;
        nDays = days;
    }

    /**
     * Internal method that gives one coin to the assigned dwarf
     */
    private void distributeCoins() {
        if(nCoins>0) {
            dwarf.giveCoin();
            nCoins--;
        }
    }


    /**
     * Checks if the pot has gold coins
     * @return true if there are still coins in the pot
     */
    public boolean hasGold() {
        return nCoins>0;
    }


    /**
     * Assign a dwarf to the pot
     * @param d The dwarf
     */
    public void startMission( Dwarf d ) {
        if(dwarf == null) {
            // Reset the mission time
            missionTime = 0;
            dwarf = d;
        }
    }

    /**
     * Checks if the pot has a dwarf assigned to it
     * @return true if a dwarf is assigned
     */
    public boolean hasDwarf() {
        return dwarf != null;
    }

    /**
     * Gets the team that is assigned to the pot
     * @return the team assigned to the pot
     */
    public Dwarf getDwarf() {
        return dwarf;
    }
    /**
     * Remove the dwarf from the pot and reset the time elapsed
     */
    public void clearMission() {
        // Null means that no dwarf is assigned
        dwarf = null;
        missionDone = false;
    }

    /**
     * Check the status of the mission to the pot
     * @return true if the team successfully completed the mission
     */
    public boolean isMissionDone() {
        return missionDone;
    }

    /**
     *  Execute 1 day of elapsed time - don't call this function
     */
    public void nextDay() {
        if( dwarf != null && !isMissionDone() ) {

            // Increase mission duration
            missionTime++;

            // If mission is now complete, give coins to dwarves
            if(missionTime == nDays) {
                missionDone = true;
                distributeCoins();
            }

        }
    }


}
