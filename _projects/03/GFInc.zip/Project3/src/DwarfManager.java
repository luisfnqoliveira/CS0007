/**
 * Dwarf manager class
 * Every day the dwarf manager goes to work the same tasks await the seasoned manager (dayOfWork):
 *   1: Check the status of dwarfs travelling to pots of gold coins
 *   2: Assign new work to the idle dwarf workers
 * First, the manager checks all the pots that have an ongoing mission for completion.
 *      If the mission has been completed, then the manager collects the gold from the dwarf assigned to it.
 *      If the mission is not completed, then nothing happens.
 * The second part involves checking if the pots still have some gold in them, and assign a dwarf to that pot.
 */
public class DwarfManager {

    /**
     * Array containing the dwarves working for the manager
     */
    private Dwarf[] dwarves;

    /**
     * Array containing the pots of gold known to dwarf-kind
     */
    private PotOfGoldCoins[] potsOfGoldCoins;

    /**
     * Amount of gold collected so far
     */
    private int goldCoins = 0;


    /**
     * The constructor initializes the manager data structures to let it know about
     *    which dwarves are working under its supervision and which pots are known
     * @param dwarves array of dwarves
     * @param potsOfGoldCoins array of pots of gold
     */
    public DwarfManager(Dwarf[] dwarves, PotOfGoldCoins[] potsOfGoldCoins) {
        this.dwarves = dwarves;
        this.potsOfGoldCoins = potsOfGoldCoins;
    }

    /**
     * Searches for an idle dwarf, returns the first invalid index if none is found
     * @return the index of the first idle dwarf or the length of the array
     */
    private int findIdleDwarf() {
        int i = 0;
        while( i<dwarves.length ) {
            if(dwarves[i].isIdle()) {
                return i;
            }
            i++;
        }
        return i;
    }

    /**
     * Assign an idle dwarf to a pot of gold coins and start the mission
     * @param pot - the pot of gold coins that gets a dwarf
     * @return true if an idle dwarf was found and assigned
     */
    private boolean startNewMission(PotOfGoldCoins pot) {
        // Check if we've reached the end of the list and no dwarves are idle
        int dwarfIndex = findIdleDwarf();
        if(dwarfIndex != dwarves.length) {
            System.out.println("Assigning " + dwarves[dwarfIndex]);
            dwarves[dwarfIndex].setBusy();
            pot.startMission(dwarves[dwarfIndex]);
            return true;
        }
        return false;
    }

    /**
     * Finishes the mission: collect coins and un-assign the dwarf.
     * @param pot the pot for which the mission was completed
     */
    private void wrapUpMission(PotOfGoldCoins pot) {

        Dwarf dwarf = pot.getDwarf();
        System.out.println("Dwarf " + dwarf + " has returned!");

        int goldCoinsCollected = dwarf.getCoin();
        goldCoins += goldCoinsCollected;
        System.out.println( dwarf + " collected " + goldCoinsCollected + " gold coin(s) today.");

        pot.clearMission();
        dwarf.setIdle();
    }


    /**
     * This function is called to have the Dwarf Manager do its daily routine.
     */
    public void dayOfWork() {

        System.out.println("One more day of work!");
        System.out.println("Checking if any dwarf is back...");
        for (int i = 0; i < potsOfGoldCoins.length; i++) {
            if( potsOfGoldCoins[i].isMissionDone() ) {
                System.out.println("Dwarf returned from its mission to gold pot: " + i);
                wrapUpMission(potsOfGoldCoins[i]);
            }
        }

        System.out.println("Doing job assignments for the day...");
        for (int i = 0; i < potsOfGoldCoins.length; i++) {
            if( !potsOfGoldCoins[i].hasDwarf() && potsOfGoldCoins[i].hasGold() ) {
                boolean success = startNewMission(potsOfGoldCoins[i]);
                if (success) {
                    System.out.println("Assigned a dwarf to pot: " + i);
                } else {
                    System.out.println("No dwarfs available! No one was assigned to pot: " + i);
                }
            }
        }

        System.out.println("Glad to report our vaults contain " + goldCoins + " gold coins so far.");

    }

}
