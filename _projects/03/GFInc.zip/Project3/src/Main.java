public class Main {

    /**
     * The dwarf manager
     */
    static DwarfManager manager;

    /**
     * List of dwraves
     */
    static Dwarf[] dwarves = {
            new Dwarf("Azaghâl"),
            new Dwarf("Balin"),
            new Dwarf("Dís"),
            new Dwarf("Durin "),
            new Dwarf("Gimli"),
            new Dwarf("Náin"),
            new Dwarf("Thrór")
    };

    /**
     * Pots of gold
     */
    static PotOfGoldCoins[] potsOfGoldCoins = {
            new PotOfGoldCoins(3, 2),
            new PotOfGoldCoins(3, 1),
            new PotOfGoldCoins(4, 3),
    };

    /**
     * Number of members in a team
     */
    static int nTeamMembers = 3;

    /**
     * Simulates one day of the scenario
     * @return true if the mission is done
     */
    public static boolean runTime( int day ) {

        // Have the manager do the assignments for the day
        manager.dayOfWork();

        // Simulate all the dwarfs for a day
        for (int i = 0; i<dwarves.length; i++) {
            dwarves[i].nextDay();
        }

        // Simulate all the pots for a day
        boolean done = true;
        for (int i = 0; i<potsOfGoldCoins.length; i++) {
            PotOfGoldCoins potOfGold = potsOfGoldCoins[i];
            // Move a day forwards for a pot - this is what makes
            //   the travel time elapse
            potOfGold.nextDay();

            // Check if all the gold was collected
            //   making sure all pots don't have on-going missions
            //   (if the mission is done, then the manager didn't collect the gold!)
            // This will decide if the simulation is done or not
            if(potOfGold.hasGold() || potOfGold.isMissionDone()) {
                done = false;
            }
        }

        // Fail-safe -- Student-proof(?) protection that makes sure the program ends
        if ( day > 10000 ) {
            done = true;
        }
        return done;
    }


    public static void main(String args[]) {

        manager = new DwarfManager(dwarves, potsOfGoldCoins);

        int day = 0;
        // Run simulation
        do {
            System.out.println("\nSimulating day " + day);
        } while ( !runTime(day++) );

        System.out.println("\nSimulation was completed!");


    }
}
