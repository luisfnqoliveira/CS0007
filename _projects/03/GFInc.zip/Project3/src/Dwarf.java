/**
 * Dwarf class - Dwarfs are hard workers, they are assigned by their manager to go in missions to pots of gold coins
 *                  however, each one of them can only hold 1 coin at a time.
 */
public class Dwarf {


    /**
     * Variable that tracks if the dwarf is in a mission or not
     */
    private boolean assigned = false;

    /**
     * Variable that flags if the dwarf has a coin
     */
    private boolean coin;

    /**
     * The name of this dwarf
     */
    private String name;

    /**
     * Constructor
     * @param name  - the name of this dwarf
     */
    public Dwarf(String name) {
        this.name = name;
    }

    /**
     * Prints the name of the dwarf
     * @return The name of the dwarf
     */
    @Override
    public String toString() {
        return name;
    }

    /**
     * If this function is called, then the dwarf is being given a coin
     */
    public void giveCoin() {
        this.coin = true;
    }

    /**
     * If this function is called, the dwarf gives his coins back. Reset the number of coins to zero!
     * @return the number of coins owned by the dwarf
     */
    public int getCoin() {
        int retCoin = 0;
        if (coin) {
            retCoin = 1;
            coin = false;
        }
        return retCoin;
    }


    /**
     * The dwarf is now in a mission
     */
    public void setBusy() {
        assigned = true;
    }

    /**
     * The dwarf is now NOT in a mission
     */
    public void setIdle() {
        assigned = false;
    }

    /**
     * Check if the dwarf is in a mission
     */
    public boolean isIdle() {
        return !assigned;
    }

    /**
     *  Execute 1 day of elapsed time - you can/should modify this function
     *  but don't call it! It's only called in the Main class!
     */
    public void nextDay() {
    }

}
